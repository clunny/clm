---
title: "project"
status: unbuilt
owners: []
depends_on: []
paths: [".claude/settings.json", ".gitignore", "clm.toml", "scripts/clm-check.sh"]
outside: []
successor: ""
---

## Contract

What project offers its users. `/clm:init` drafts it with you.

## Design

How project is split into components.
